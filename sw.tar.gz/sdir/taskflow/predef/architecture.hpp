#pragma once

#include "architecture/arm.hpp"
#include "architecture/mips.hpp"
#include "architecture/ppc.hpp"
#include "architecture/x86.hpp"
