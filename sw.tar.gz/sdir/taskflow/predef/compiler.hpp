#pragma once

#include "compiler/clang.hpp"
#include "compiler/gcc.hpp"
#include "compiler/msvc.hpp"

