// 2019-05-20 created by Chun-Xun Lin
//   - modifed from boost/predef/detail/os_detected.h

#pragma once

#ifndef TF_PREDEF_DETAIL_OS_DETECTED
  #define TF_PREDEF_DETAIL_OS_DETECTED 1
#endif
